package com.ri.hosts;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

/**
 * Application to merge host files from various sources into one, distinct new hosts file 
 * 
 * @author Rudolf
 */
public class MergeHosts {
	private File folder = null; 
	
	public MergeHosts(File folder) throws IOException {
		System.out.println("MergeHosts - looking for \"hosts.*\" files in: " + folder.getCanonicalPath());
		
		this.folder = folder;
		
		if (!folder.exists() || !folder.isDirectory() || !folder.canRead()){
			throw new IOException("ERROR - Invalid folder: " + folder.getCanonicalPath());
		}
	}
	
	public void mergeIt() throws Exception {
		System.out.println("\nFound hosts files:");
		
		List<File> hostFiles = new ArrayList<File>();
		File files[] = folder.listFiles();
		for (File file : files){
			if (file.getName().toLowerCase().startsWith("hosts.") && !file.getName().toLowerCase().endsWith("zip") && !file.getName().toLowerCase().endsWith("rar") && !file.getName().toLowerCase().endsWith("final")){
				hostFiles.add(file);
				System.out.println("   " + file.getName());
			}
		}
		
		if (hostFiles.size() == 0){
			throw new Exception("ERROR - No hosts files found matching pattern \"hosts.*\"");
		}
		
		Set<String> distinctDomains = new TreeSet<String>();
		for (File file : hostFiles){
			System.out.println("\nProcessing: " + file.getName());
			
			FileReader fr = null;
			BufferedReader br = null;
			try {
				fr = new FileReader(file);
				br = new BufferedReader(fr);
				
				int collisions = 0;
				int domainCount = 0;
				String line = null;
				while ((line = br.readLine()) != null){
					String parsingLine = line.replaceAll("#.*", ""); //cut away any commented lines, or cut off any trailing comments
					
					parsingLine = parsingLine.replaceAll("[ \\t\\r\\n\\v\\f]+", " "); //condense all whitespace to a single space
					String set[] = parsingLine.split(" ");
					if (set.length == 2){
						//correct line
					} else if (set.length == 0 || set[0].length() == 0){
						//commented line or empty line
						continue;
					} else {
						System.out.println("   Unable to parse line: " + line);
						continue;
					}
					
					boolean newDomain = distinctDomains.add(set[1].toLowerCase());
					if (!newDomain){
						collisions++;
					}
					
					domainCount++;
				}

				System.out.println("   " + domainCount + " domains successfully extracted, with " + collisions + " collisions");
			} catch (IOException ioe){
				throw new Exception("ERROR - Unable to parse " + file.getName() + ": " + ioe.getMessage());
			} finally {
				try {
					br.close();
				} catch (Throwable t){
					//consume
				}
				try {
					fr.close();
				} catch (Throwable t){
					//consume
				}
			}
		}
		
		FileWriter fw = null;
		BufferedWriter bw = null;
		File finalHosts = null;
		try {
			finalHosts = new File(folder.getCanonicalPath() + File.separator + "hosts.final");
			fw = new FileWriter(finalHosts, false);
			bw = new BufferedWriter(fw, 4 * 1024);
			
			distinctDomains.remove("localhost");
			bw.write("127.0.0.1 localhost\n");

			for (String domain : distinctDomains){
				bw.write("127.0.0.1 " + domain + "\n");
			}
		} catch (IOException ioe){
			throw new Exception("ERROR - Unable to write merged hosts file: " + ioe.getMessage());
		} finally {
			try {
				bw.flush();
			} catch (Throwable t){
				//consume
			}
			try {
				fw.flush();
			} catch (Throwable t){
				//consume
			}
			try {
				bw.close();
			} catch (Throwable t){
				//consume
			}
			try {
				fw.close();
			} catch (Throwable t){
				//consume
			}
		}
		
		System.out.println("\nDONE!");
		System.out.println("Final hosts file: " + finalHosts.getCanonicalPath());
		System.out.println("Size: " + (finalHosts.length() / 1024) + "KB");
	}
	
	public static void main(String[] args) {
		try {
			MergeHosts app = null;
			if (args.length == 1){
				app = new MergeHosts(new File(args[0]));
			} else {
				app = new MergeHosts(new File("."));
			}
			
			app.mergeIt();
		} catch(Exception e){
			System.err.println(e.getMessage());
		}
	}

}
