See "Block ads on PC & Android with an uber HOSTS file!" on http://mathdotrandom.blogspot.com/
Date: Dec 2010